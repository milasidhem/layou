package com.example.myapplication.vue;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.myapplication.controleur.Controle;
import com.example.testprojet.R;

public class ChangePassword extends AppCompatActivity {

    Controle controle;
    SharedPreferences sharedPreferences;
    EditText pass1,pass2,pass3;
    String username,passw1,passw2,passw3 = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_password);
        sharedPreferences = getSharedPreferences("autoLogin", Context.MODE_PRIVATE);
        username = sharedPreferences.getString("username", null);
    }
    public void SubmitP(View v){
        if(v.getId()==R.id.submitpsw){
            pass1 = findViewById(R.id.pass1);
            pass2 = findViewById(R.id.pass2);
            pass3 = findViewById(R.id.pass3);
            passw1 = pass1.getText().toString();
            passw2 = pass2.getText().toString();
            passw3 = pass3.getText().toString();
            if(passw1.contentEquals("")||passw2.contentEquals("")||passw3.contentEquals("")){
                Toast.makeText(ChangePassword.this,"Saisir incomplet",Toast.LENGTH_LONG).show();
            }
            else if(!passw3.contentEquals(passw2)){
                Toast.makeText(ChangePassword.this,"Confirm new password again",Toast.LENGTH_LONG).show();
            }
            else{
                this.controle = controle.getInstance(this);
                this.controle.changePassword(username,passw1,passw2);
                Intent swwitchSubPH = new Intent(this,ManageAccount.class);
                startActivity(swwitchSubPH);
                Toast.makeText(ChangePassword.this,"Your password have been changed",Toast.LENGTH_LONG).show();
            }
        }
    }
}
