package com.example.myapplication.vue;


import androidx.fragment.app.FragmentActivity;

import android.os.Bundle;

import com.example.myapplication.controleur.Controle;
import com.example.testprojet.R;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;


import androidx.annotation.DrawableRes;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.gms.maps.MapsInitializer;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.Marker;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback, GoogleMap.OnMarkerClickListener{

    String TAG;
    private GoogleMap mMap;
    Marker test;
    Marker gaz;
    Double value;
    Double value2;
    int type;
    int etat;
    int i=0;
    private Controle controle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        this.controle = Controle.getInstance(this);
        this.controle.all();
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
        value = controle.lesx[0];
        value2 =  controle.lesy[0];
        type=controle.lestypes[0];
        etat=controle.lesetat[0];
    }

    @Override
    protected void onResume() {
        super.onResume();
        this.controle.all();
    }

    /*type   etat*/
    public Bitmap getMarkerBitmapFromView(@DrawableRes int resId,int i,int j) {

        if (i == 1) {
            if (j == 2) {
                View customMarkerView = ((LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE)).inflate(R.layout.marker, null);
                ImageView markerImageView = (ImageView) customMarkerView.findViewById(R.id.rofile_image);
                markerImageView.setImageResource(resId);
                customMarkerView.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);
                customMarkerView.layout(0, 0, customMarkerView.getMeasuredWidth(), customMarkerView.getMeasuredHeight());
                customMarkerView.buildDrawingCache();
                Bitmap returnedBitmap = Bitmap.createBitmap(customMarkerView.getMeasuredWidth(), customMarkerView.getMeasuredHeight(),
                        Bitmap.Config.ARGB_8888);
                Canvas canvas = new Canvas(returnedBitmap);
                canvas.drawColor(Color.WHITE, PorterDuff.Mode.SRC_IN);
                Drawable drawable = customMarkerView.getBackground();
                if (drawable != null)
                    drawable.draw(canvas);
                customMarkerView.draw(canvas);
                return returnedBitmap;
            } else if (j == 1) {
                View customMarkerView = ((LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE)).inflate(R.layout.markeret1, null);
                ImageView markerImageView = (ImageView) customMarkerView.findViewById(R.id.water);
                markerImageView.setImageResource(resId);
                customMarkerView.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);
                customMarkerView.layout(0, 0, customMarkerView.getMeasuredWidth(), customMarkerView.getMeasuredHeight());
                customMarkerView.buildDrawingCache();
                Bitmap returnedB = Bitmap.createBitmap(customMarkerView.getMeasuredWidth(), customMarkerView.getMeasuredHeight(),
                        Bitmap.Config.ARGB_8888);
                Canvas canvas = new Canvas(returnedB);
                canvas.drawColor(Color.WHITE, PorterDuff.Mode.SRC_IN);
                Drawable drawable = customMarkerView.getBackground();
                if (drawable != null)
                    drawable.draw(canvas);
                customMarkerView.draw(canvas);
                return returnedB;
            }
            else if (j == 3) {
                View customMarkerView = ((LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE)).inflate(R.layout.waterred, null);
                ImageView markerImageView = (ImageView) customMarkerView.findViewById(R.id.watered);
                markerImageView.setImageResource(resId);
                customMarkerView.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);
                customMarkerView.layout(0, 0, customMarkerView.getMeasuredWidth(), customMarkerView.getMeasuredHeight());
                customMarkerView.buildDrawingCache();
                Bitmap returnedB = Bitmap.createBitmap(customMarkerView.getMeasuredWidth(), customMarkerView.getMeasuredHeight(),
                        Bitmap.Config.ARGB_8888);
                Canvas canvas = new Canvas(returnedB);
                canvas.drawColor(Color.WHITE, PorterDuff.Mode.SRC_IN);
                Drawable drawable = customMarkerView.getBackground();
                if (drawable != null)
                    drawable.draw(canvas);
                customMarkerView.draw(canvas);
                return returnedB;
            }

        } else if (i == 2) {
            if(j==2){
                View m = ((LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE)).inflate(R.layout.markert, null);
                ImageView mi = (ImageView) m.findViewById(R.id.file_image);
                mi.setImageResource(resId);
                m.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);
                m.layout(0, 0, m.getMeasuredWidth(), m.getMeasuredHeight());
                m.buildDrawingCache();
                Bitmap returnedBitma = Bitmap.createBitmap(m.getMeasuredWidth(), m.getMeasuredHeight(),
                        Bitmap.Config.ARGB_8888);
                Canvas canva = new Canvas(returnedBitma);
                canva.drawColor(Color.WHITE, PorterDuff.Mode.SRC_IN);
                Drawable rawable = m.getBackground();
                if (rawable != null)
                    rawable.draw(canva);
                m.draw(canva);
                return returnedBitma;}
            else if (j == 3) {
                View customMarkerView = ((LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE)).inflate(R.layout.markerrg, null);
                ImageView markerImageView = (ImageView) customMarkerView.findViewById(R.id.route);
                markerImageView.setImageResource(resId);
                customMarkerView.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);
                customMarkerView.layout(0, 0, customMarkerView.getMeasuredWidth(), customMarkerView.getMeasuredHeight());
                customMarkerView.buildDrawingCache();
                Bitmap returnedB = Bitmap.createBitmap(customMarkerView.getMeasuredWidth(), customMarkerView.getMeasuredHeight(),
                        Bitmap.Config.ARGB_8888);
                Canvas canvas = new Canvas(returnedB);
                canvas.drawColor(Color.WHITE, PorterDuff.Mode.SRC_IN);
                Drawable drawable = customMarkerView.getBackground();
                if (drawable != null)
                    drawable.draw(canvas);
                customMarkerView.draw(canvas);
                return returnedB;
            }

            else if (j == 1) {
                View customMarkerView = ((LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE)).inflate(R.layout.roadred, null);
                ImageView markerImageView = (ImageView) customMarkerView.findViewById(R.id.route);
                markerImageView.setImageResource(resId);
                customMarkerView.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);
                customMarkerView.layout(0, 0, customMarkerView.getMeasuredWidth(), customMarkerView.getMeasuredHeight());
                customMarkerView.buildDrawingCache();
                Bitmap returnedB = Bitmap.createBitmap(customMarkerView.getMeasuredWidth(), customMarkerView.getMeasuredHeight(),
                        Bitmap.Config.ARGB_8888);
                Canvas canvas = new Canvas(returnedB);
                canvas.drawColor(Color.WHITE, PorterDuff.Mode.SRC_IN);
                Drawable drawable = customMarkerView.getBackground();
                if (drawable != null)
                    drawable.draw(canvas);
                customMarkerView.draw(canvas);
                return returnedB;
            }

        }

        else if (i == 3) {
            if (j == 2) {
                View tree = ((LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE)).inflate(R.layout.markertr, null);
                ImageView treei = (ImageView) tree.findViewById(R.id.ile_image);
                treei.setImageResource(resId);
                tree.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);
                tree.layout(0, 0, tree.getMeasuredWidth(), tree.getMeasuredHeight());
                tree.buildDrawingCache();
                Bitmap returnedBit = Bitmap.createBitmap(tree.getMeasuredWidth(), tree.getMeasuredHeight(),
                        Bitmap.Config.ARGB_8888);
                Canvas canv = new Canvas(returnedBit);
                canv.drawColor(Color.WHITE, PorterDuff.Mode.SRC_IN);
                Drawable rawable = tree.getBackground();
                if (rawable != null)
                    rawable.draw(canv);
                tree.draw(canv);
                return returnedBit;
            } else if (j == 3) {
                View customMarkerView = ((LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE)).inflate(R.layout.electrgreen, null);
                ImageView markerImageView = (ImageView) customMarkerView.findViewById(R.id.elect);
                markerImageView.setImageResource(resId);
                customMarkerView.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);
                customMarkerView.layout(0, 0, customMarkerView.getMeasuredWidth(), customMarkerView.getMeasuredHeight());
                customMarkerView.buildDrawingCache();
                Bitmap returnedB = Bitmap.createBitmap(customMarkerView.getMeasuredWidth(), customMarkerView.getMeasuredHeight(),
                        Bitmap.Config.ARGB_8888);
                Canvas canvas = new Canvas(returnedB);
                canvas.drawColor(Color.WHITE, PorterDuff.Mode.SRC_IN);
                Drawable drawable = customMarkerView.getBackground();
                if (drawable != null)
                    drawable.draw(canvas);
                customMarkerView.draw(canvas);
                return returnedB;
            }


            else if (j == 1) {
                View customMarkerView = ((LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE)).inflate(R.layout.electrred, null);
                ImageView markerImageView = (ImageView) customMarkerView.findViewById(R.id.electred);
                markerImageView.setImageResource(resId);
                customMarkerView.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);
                customMarkerView.layout(0, 0, customMarkerView.getMeasuredWidth(), customMarkerView.getMeasuredHeight());
                customMarkerView.buildDrawingCache();
                Bitmap returnedB = Bitmap.createBitmap(customMarkerView.getMeasuredWidth(), customMarkerView.getMeasuredHeight(),
                        Bitmap.Config.ARGB_8888);
                Canvas canvas = new Canvas(returnedB);
                canvas.drawColor(Color.WHITE, PorterDuff.Mode.SRC_IN);
                Drawable drawable = customMarkerView.getBackground();
                if (drawable != null)
                    drawable.draw(canvas);
                customMarkerView.draw(canvas);
                return returnedB;
            }

        }

        else if(i==4) {
            if(j==2){
            View four = ((LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE)).inflate(R.layout.markerfo, null);
            ImageView fouri = (ImageView) four.findViewById(R.id.le_image);
            fouri.setImageResource(resId);
            four.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);
            four.layout(0, 0, four.getMeasuredWidth(), four.getMeasuredHeight());
            four.buildDrawingCache();
            Bitmap returnedBi = Bitmap.createBitmap(four.getMeasuredWidth(), four.getMeasuredHeight(),
                    Bitmap.Config.ARGB_8888);
            Canvas can = new Canvas(returnedBi);
            can.drawColor(Color.WHITE, PorterDuff.Mode.SRC_IN);
            Drawable rawable = four.getBackground();
            if (rawable != null)
                rawable.draw(can);
            four.draw(can);
            return returnedBi;

        }else if(j==3){
            View customMarkerView = ((LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE)).inflate(R.layout.gasgreen, null);
            ImageView markerImageView = (ImageView) customMarkerView.findViewById(R.id.gas);
            markerImageView.setImageResource(resId);
            customMarkerView.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);
            customMarkerView.layout(0, 0, customMarkerView.getMeasuredWidth(), customMarkerView.getMeasuredHeight());
            customMarkerView.buildDrawingCache();
            Bitmap returnedB = Bitmap.createBitmap(customMarkerView.getMeasuredWidth(), customMarkerView.getMeasuredHeight(),
                    Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(returnedB);
            canvas.drawColor(Color.WHITE, PorterDuff.Mode.SRC_IN);
            Drawable drawable = customMarkerView.getBackground();
            if (drawable != null)
                drawable.draw(canvas);
            customMarkerView.draw(canvas);
            return returnedB;
        }


        else if (j == 1) {
            View customMarkerView = ((LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE)).inflate(R.layout.gasred, null);
            ImageView markerImageView = (ImageView) customMarkerView.findViewById(R.id.gasrred);
            markerImageView.setImageResource(resId);
            customMarkerView.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);
            customMarkerView.layout(0, 0, customMarkerView.getMeasuredWidth(), customMarkerView.getMeasuredHeight());
            customMarkerView.buildDrawingCache();
            Bitmap returnedB = Bitmap.createBitmap(customMarkerView.getMeasuredWidth(), customMarkerView.getMeasuredHeight(),
                    Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(returnedB);
            canvas.drawColor(Color.WHITE, PorterDuff.Mode.SRC_IN);
            Drawable drawable = customMarkerView.getBackground();
            if (drawable != null)
                drawable.draw(canvas);
            customMarkerView.draw(canvas);
            return returnedB;
        }

        }

        return null;
    }
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        // Add a marker in Sydney and move the camera
        //LatLng sba = new LatLng(37.421, -122.084);
        LatLng sba = new LatLng( controle.lesx[0],  controle.lesy[0]);
        mMap.moveCamera(CameraUpdateFactory.newLatLng(sba));
        mMap.setOnMarkerClickListener(this);
        mMap.animateCamera( CameraUpdateFactory.zoomTo( 13 ) );
        Log.d(TAG, "onMapReady() called with");
        MapsInitializer.initialize(this);
        while( i<controle.limit) {
            mMap.setInfoWindowAdapter(new GoogleMap.InfoWindowAdapter(){
                // Use default InfoWindow frame
                @Override
                public View getInfoWindow(Marker marker) {
                    return null;
                }

                // Defines the contents of the InfoWindow
                @Override
                public View getInfoContents(Marker marker) {

                    // Getting view from the layout file info_window_layout
                    View v = getLayoutInflater().inflate(R.layout.custom_info_window, null);

                    // Getting reference to the TextView to set title
                    TextView note =  v.findViewById(R.id.note);
                    TextView notet =  v.findViewById(R.id.notet);
                    TextView notetr =  v.findViewById(R.id.notetr);
                    ImageView imageView = findViewById(R.id.image);
                    //Loading image using Picasso
                    if((Integer)marker.getTag()==1){
                        note.setText("titre  "+marker.getTitle() );
                        notet.setText("description  "+marker.getSnippet());
                        notetr.setText("position  "+ marker.getPosition() );}
                    return v; }});
            addCustomMarker(controle.lesx[i],controle.lesy[i],controle.lestypes[i],controle.lesetat[i],i);
            i=i+1;
        }
    }

    @SuppressLint("ResourceType")
    public Marker addCustomMarker(double x,double y,int type,int etat,int k) {

        // adding a marker on map with image from  drawable
        if(type==1){
             mMap.addMarker(new MarkerOptions().position(new LatLng(x,y))
                    .icon(BitmapDescriptorFactory.fromBitmap(getMarkerBitmapFromView(R.drawable.water,type,etat))).title(controle.lestitle[k]).snippet(controle.desc[k]+"\netat : "+controle.lesetat[k])).setTag(1);}
        else if (type==2){
            mMap.addMarker(new MarkerOptions().position(new LatLng(x,y))
                .icon(BitmapDescriptorFactory.fromBitmap(getMarkerBitmapFromView(R.drawable.route,type,etat))).title(controle.lestitle[k]).snippet(controle.desc[k]+"\netat : "+controle.lesetat[k])).setTag(1);}
        else if(type==3){
            mMap.addMarker(new MarkerOptions().position(new LatLng(x,y))
                .icon(BitmapDescriptorFactory.fromBitmap(getMarkerBitmapFromView(R.drawable.electricite,type,etat))).title(controle.lestitle[k]).snippet(controle.desc[k]+"\netat : "+controle.lesetat[k])).setTag(1);}
        else if(type==4) {
             mMap.addMarker(new MarkerOptions().position(new LatLng(x, y))
                    .icon(BitmapDescriptorFactory.fromBitmap(getMarkerBitmapFromView(R.drawable.gas, type,etat))).title(controle.lestitle[k]).snippet(controle.desc[k]+"\netat : "+controle.lesetat[k])).setTag(1);
        }
        return null;
    }




    public boolean onMarkerClick(final Marker marker) {
        return false;
    }
}