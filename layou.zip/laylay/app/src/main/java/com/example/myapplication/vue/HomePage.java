package com.example.myapplication.vue;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.example.myapplication.controleur.Controle;
import com.example.testprojet.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class HomePage extends AppCompatActivity {

    private BottomNavigationView navigation;
    private Controle controle;
    SharedPreferences sharedpreferences;
    String username;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);
        this.controle = Controle.getInstance(this);
        sharedpreferences = getSharedPreferences("autoLogin", Context.MODE_PRIVATE);
        username = sharedpreferences.getString("username", null);
        Toast toast = Toast.makeText(this, "hello  "+username, Toast.LENGTH_LONG);
        View toastView = toast.getView(); // This'll return the default View of the Toast.

        /* And now you can get the TextView of the default View of the Toast. */
        TextView toastMessage = (TextView) toastView.findViewById(android.R.id.message);
        toastMessage.setTextSize(15);
        toastMessage.setTextColor(Color.GRAY);
        toastMessage.setCompoundDrawablesWithIntrinsicBounds(R.mipmap.ic_launcher_mine, 0, 0, 0);
        toastMessage.setGravity(Gravity.CENTER);
        toastMessage.setCompoundDrawablePadding(10);
        toastView.setBackgroundColor(Color.WHITE);
        toast.setGravity(Gravity.TOP , 0, 0);

        toast.show();
        controle.USER = username;
        controle.mine(controle.USER);
        controle.all();
        navigation = findViewById(R.id.bottom_navigation);
        navigation.setOnNavigationItemSelectedListener(navi);
    }

    @Override
    protected void onResume(){
        super.onResume();
        //Toast.makeText(this,"Welcome "+username,Toast.LENGTH_LONG).show();
        controle.mine(username);
    }

    private BottomNavigationView.OnNavigationItemSelectedListener navi = new
            BottomNavigationView.OnNavigationItemSelectedListener() {
                @Override
                public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                    switch (menuItem.getItemId()){
                        case R.id.write :
                            Intent intentW = new Intent(HomePage.this, WriteReport.class);
                            //intentW.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK);
                            startActivity(intentW);
                            break;
                        case R.id.search :
                            if(controle.limit==0){
                                Toast.makeText(HomePage.this,"no reports to show",Toast.LENGTH_LONG).show();
                            }
                            else {
                                Intent intentS = new Intent(HomePage.this, MapsActivity.class);
                                startActivity(intentS);
                            }
                            break;
                        case R.id.list:
                            Intent intentL = new Intent(HomePage.this, ListReports.class);
                            //intentL.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK);
                            startActivity(intentL);
                            break;
                        case R.id.manage :
                            Intent intentM = new Intent(HomePage.this, ManageAccount.class);
                            //intentM.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK);
                            startActivity(intentM);
                            break;
                    }
                    return false;
                }
            };
}
