package com.example.myapplication.vue;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.myapplication.controleur.Controle;
import com.example.testprojet.R;

public class Login extends AppCompatActivity {

    EditText username;
    EditText password;
    Controle controle;
    SharedPreferences sharedpreferences;
    Integer autoSave;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log);
        sharedpreferences = getSharedPreferences("autoLogin", Context.MODE_PRIVATE);
        int j = sharedpreferences.getInt("key", 0);
        //Default is 0 so autologin is disabled
        if(j > 0){
            Intent activity = new Intent(getApplicationContext(), HomePage.class);
            startActivity(activity);
        }
        else
            init();
    }

    public void init() {
        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
        this.controle = Controle.getInstance(this);
        controle.mesRapports.clear();
    }


    public void check(View v){
        if(v==findViewById(R.id.login)){
            String user ;
            String pass ;
            user = username.getText().toString();
            pass = password.getText().toString();
            if(username.getText().toString().isEmpty()||password.getText().toString().isEmpty())
                Toast.makeText(this,"Saisir incomplet",Toast.LENGTH_LONG).show();
            else{
                controle.loginUser(user,pass);
            //v.performClick();
                if(controle.IS_CHECKED){
                    autoSave = 1;
                    SharedPreferences.Editor editor = sharedpreferences.edit();
                    editor.putString("username", user);
                    editor.putInt("key", autoSave);
                    editor.apply();
                    Intent intent = new Intent(this, HomePage.class);
                    startActivity(intent);
                }
                else
                    Toast.makeText(this,"username or password inccorect",Toast.LENGTH_LONG).show();
        }
        }
    }

    public void registre(View v){
        if(v==findViewById(R.id.newtxt)){
            Intent intent = new Intent(this, Registre.class);
            startActivity(intent);
        }
        }
}
