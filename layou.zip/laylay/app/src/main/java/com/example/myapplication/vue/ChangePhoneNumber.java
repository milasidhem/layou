package com.example.myapplication.vue;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.myapplication.controleur.Controle;
import com.example.testprojet.R;

public class ChangePhoneNumber extends AppCompatActivity {
    Controle controle;
    SharedPreferences sharedPreferences;
    EditText phonetxt;
    String phone = "";
    String username;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_phone_number);
        phonetxt = findViewById(R.id.phonetxt);
        //controle.all();
        sharedPreferences = getSharedPreferences("autoLogin", Context.MODE_PRIVATE);
        username = sharedPreferences.getString("username", null);
    }
    public void SubmitPH(View v){
        if(v.getId()==R.id.changeP){
            phonetxt = findViewById(R.id.phonetxt);
            phone = phonetxt.getText().toString();
            if(phone.contentEquals("")){
                Toast.makeText(ChangePhoneNumber.this,"Saisir incomplet",Toast.LENGTH_LONG).show();
            }
            else{
                this.controle = controle.getInstance(this);
                this.controle.changePhone(username,phone);
                Intent swwitchSubPH = new Intent(this,ManageAccount.class);
                startActivity(swwitchSubPH);
            }
        }
    }
}
