package com.example.myapplication.controleur;

import android.content.Context;

import com.example.myapplication.model.AcceDistant;
import com.example.myapplication.model.Report;
import com.example.myapplication.model.User;
import com.example.myapplication.outils.MesOutils;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public final class Controle {

    private static Controle instance = null;
    public static Report report;
    private static AcceDistant acceDistant;
    public static boolean IS_EMPTY;
    public static boolean IS_EMPTYM;
    public static boolean IS_CHECKED;
    public static boolean EXISTS ;
    public ArrayList<Report> mesRapports = new ArrayList<Report>();
    public ArrayList<String> lesTypes = new ArrayList<String>();
    public Double[] lesx= new Double[10] ;
    public Double[] lesy =new Double[10];
    public Integer[] lestypes = new Integer[10];
    public String[] lestitle = new String[10];
    public String[] usernames = new String[10];
    public Integer[] lesetat = new Integer[10];
    public String[] desc = new String[10];
    public static int limit = 0 ;
    public static String USER;


    public void setMesRapports(ArrayList<Report> mesRapports) {
        this.mesRapports = mesRapports;
    }
    public ArrayList<Report> getMesRapports() {
        return mesRapports;
    }


    public ArrayList<String> getTypes() {
        return lesTypes;
    }
    public void setLesTypes(ArrayList<String> lesTypes) {
        this.lesTypes = lesTypes;
    }

    /**
     * constrecteur private
     */
    private Controle(){
        super();
    }

    /** pour qu'on avoir toujours une et une seule instance
     * creation de l'instance
     * @return instance
     */
    public static final Controle getInstance(Context contexte){
        if(Controle.instance==null){
            Controle.instance = new Controle();
            acceDistant = new AcceDistant();
            acceDistant.envoi("tous",new JSONArray());
            acceDistant.envoi("type",new JSONArray());
        }
        return Controle.instance;
    }

    /**
     * ask for all reports from server
     */
    public void all(){
        acceDistant.envoi("tous",new JSONArray());
    }

    public void mine(String username){
        acceDistant.envoi("mine",convertToJSONArray(username, null));
    }

    public void types(){
        acceDistant.envoi("type",new JSONArray());
    }


    /**
     * creer un utilisateur
     * @param name
     * @param lastname
     * @param dateN
     * @param adress
     * @param phone
     * @param email
     * @param username
     * @param password
     */
    public void creeUser(String name, String lastname, String dateN, String adress, String phone, String email, String username, String password){
        User unuser = new User(name,lastname,dateN,adress,phone,email,username,password);
        acceDistant.envoi("registre",unuser.convertToJSONArray());
    }

    /**
     * check if user's input match
     * @param username
     * @param password
     */
    public void loginUser(String username, String password){
        User unuser = new User(username,password);
        acceDistant.envoi("check",unuser.convertToJSONArrayCheck());
    }

    /**
     * creation d'un report
     * @param title
     * @param description
     * @param locx
     * @param locy
     * @param type 1 pour problem d'eau et 2 pour voiri et 3 pour electricity et 4 pour gaz
     * @param image
     */
    public void creeReport(String username,String title, String description, double locx, double locy, Integer type, String image){
        Report unreport = new Report(username,title,description,locx,locy,type,image, 1 ,new Date(),null,null,null,null);
        mesRapports.add(unreport);
        acceDistant.envoi("enreg",unreport.convertToJSONArray());
    }

    /**
     * valorisation d'un report
     * @param report
     */
    public void setReport(Report report){
        Controle.report = report;
    }

    /**
     * permer de supprimer un profil dans la base distante et la collection
     * @param report
     */
    public void delReport(Report report){
        acceDistant.envoi("delr",report.convertToJSONArray());
        mesRapports.remove(report);
    }

    /**
     * permer de supprimer un profil dans la base distante
     * @param username
     */
    public void delUser(String username, String password){
        acceDistant.envoi("delu",convertToJSONArray(username,password));
    }

    public void changePhone(String username , String phone){
        acceDistant.envoi("phone",convertToJSONArray(username,phone));
    }

    public void changePassword(String username , String password, String pass){
        acceDistant.envoi("pass",convertToJSONArrayP(username,password,pass));
    }


    public JSONArray convertToJSONArray(String username, String password){
        List laList = new ArrayList();
        laList.add(username);
        laList.add(password);
        return new JSONArray(laList);
    }

    public JSONArray convertToJSONArrayP(String username, String password, String pass){
        List laList = new ArrayList();
        laList.add(username);
        laList.add(password);
        laList.add(pass);
        return new JSONArray(laList);
    }

    /**
     * recuperation du titre d'un rapport
     * @return title
     */
    public String getTitle(){
        if(report==null)
            return null;
        else
            return report.getTitle();
    }

    /**
     * recuperation du description d'un rapport
     * @return description
     */
    public String getDescription(){
        if(report==null)
            return null;
        else
            return report.getDescription();
    }

    /**
     * recuperation du longitude du la localisation d'un rapport
     * @return longitude
     */
    public double getLocx(){
        if(report==null)
            return 0;
        else
            return report.getLocx();
    }

    /**
     * recuperation du latitude du la localisation d'un rapport
     * @return latitude
     */
    public double getLocy(){
        if(report==null)
            return 0;
        else
            return report.getLocy();
    }

    /**
     * recuperation du type d'un rapport
     * @return type
     */
    public double getType(){
        if(report==null)
            return 0;
        else
            return report.getType();
    }

    /**
     * recuperation d'image d'un rapport
     * @return timage
     */
    public String getImage(){
        if(report==null)
            return null;
        else
            return report.getImage();
    }

    /**
     * recuperation du date d'un rapport
     * @return date
     */
    public Date getDate1(){
        if(report==null)
            return null;
        else
            return report.getDate1();
    }

    /**
     * recuperation d'image d'un rapport
     * @return timage
     */
    public Integer getEtat(){
        if(report==null)
            return null;
        else
            return report.getEtat();
    }
}
