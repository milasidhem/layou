package com.example.myapplication.vue;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;

import com.example.myapplication.controleur.Controle;
import com.example.testprojet.R;

public class ManageAccount extends AppCompatActivity {
    SharedPreferences sharedPreferences;
    Controle controle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_account);
        sharedPreferences = getSharedPreferences("autoLogin", Context.MODE_PRIVATE);
    }
    public void Manage(View v){
        switch (v.getId()){
            case R.id.chngpsw :
                Intent swwitchPass = new Intent(this,ChangePassword.class);
                startActivity(swwitchPass);
                break;
            case R.id.chngphn :
                Intent swwitchPho = new Intent(this,ChangePhoneNumber.class);
                startActivity(swwitchPho);
                break;
            case R.id.save :
                Intent swwitchSav = new Intent(this,HomePage.class);
                startActivity(swwitchSav);
                break;
            case R.id.delete :
                Intent swwitchDel = new Intent(this,Delete.class);
                startActivity(swwitchDel);
                break;
            case R.id.logout :
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putInt("key", 0);
                editor.apply();
                Intent swwitchLogout = new Intent(this,Login.class);
                startActivity(swwitchLogout);
                break;
            case R.id.contact :
                Intent intent = new Intent(Intent.ACTION_SENDTO, Uri.fromParts(
                        "mailto","admin@email.com", null));
                intent.putExtra(Intent.EXTRA_SUBJECT, "fg");
                intent.putExtra(Intent.EXTRA_TEXT, "dff");
                startActivity(Intent.createChooser(intent, "Choose an Email client :"));
                break;

        }
    }

}
